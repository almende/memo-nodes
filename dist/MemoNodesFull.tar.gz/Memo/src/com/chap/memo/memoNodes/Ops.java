package com.chap.memo.memoNodes;

enum Ops {
    ADD,DELETE 
}
